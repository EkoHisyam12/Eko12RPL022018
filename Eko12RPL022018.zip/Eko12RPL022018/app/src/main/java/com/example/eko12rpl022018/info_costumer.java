package com.example.eko12rpl022018;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class info_costumer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_costumer);
    }
}